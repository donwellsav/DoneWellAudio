# DWA VENU360 Integration Prompt

Copy this prompt into Claude when working in the DoneWell Audio repo to integrate the VENU360 mixer profile.

---

## Prompt

Add a VENU360 mixer profile to the DWA Companion module. The VENU360 uses the companion-module-dbx-driverack-venu360 module (a separate Companion module running simultaneously) as an OSC bridge — DWA sends OSC to the VENU360 module's OSC receive port, and it handles the HiQnet TCP protocol translation.

### What to change

**File: `companion-module/src/mixerProfiles.ts`**

1. Add `'venu360'` to the `MixerModelId` union type.

2. Add these helper functions before the Profile Registry section:

```typescript
// ═══ VENU360 (OSC via VENU360 Companion module) ═══
// Sends OSC to the VENU360 Companion module's OSC receive port.
// The VENU360 module handles HiQnet TCP translation to the hardware.
// Frequency is sent as a float Hz value — the VENU360 module formats
// it into the device's string convention (e.g. 250 → "250Hz").

function buildVenu360PeqEq(prefix: string, band: number, freqHz: number, gainDb: number, q: number): EqMessage {
  const inst = prefix || '1'
  return {
    protocol: 'osc',
    oscMessages: [
      { address: `/venu360/peqout/${inst}/band/${band}/freq`, args: [{ type: 'f', value: freqHz }] },
      { address: `/venu360/peqout/${inst}/band/${band}/gain`, args: [{ type: 'f', value: gainDb }] },
      { address: `/venu360/peqout/${inst}/band/${band}/q`, args: [{ type: 'f', value: q }] },
    ],
  }
}

function clearVenu360PeqEq(prefix: string, band: number): EqMessage {
  const inst = prefix || '1'
  return {
    protocol: 'osc',
    oscMessages: [
      { address: `/venu360/peqout/${inst}/band/${band}/gain`, args: [{ type: 'f', value: 0 }] },
    ],
  }
}

function buildVenu360Geq(prefix: string, bandIndex: number, gainDb: number): EqMessage {
  const inst = prefix || '1'
  return {
    protocol: 'osc',
    oscMessages: [
      { address: `/venu360/geq/${inst}/band/${bandIndex + 1}`, args: [{ type: 'f', value: gainDb }] },
    ],
  }
}
```

3. Add the profile to the `MIXER_PROFILES` record:

```typescript
venu360: {
  id: 'venu360',
  label: 'dbx DriveRack VENU360',
  protocol: 'osc',
  defaultPort: 9000,
  peqBands: 8,
  defaultOscPrefix: '1',
  buildEqMessage: (p) => buildVenu360PeqEq(p.prefix, p.band, p.freqHz, p.gainDb, p.q),
  buildClearMessage: (p) => clearVenu360PeqEq(p.prefix, p.band),
  buildGeqMessage: (p) => buildVenu360Geq(p.prefix, p.bandIndex, p.gainDb),
},
```

### That's it — no other files need changes

The `MixerModelId` union auto-populates the config dropdown via `MIXER_MODEL_CHOICES`. The `MixerOutput` class already handles OSC transport via `dgram`. The profile slots into the existing architecture.

### How it works at runtime

```
DWA Web App (browser) → detects feedback at 2500Hz
  ↓ POST advisory to relay
DWA Companion Module → allocates PEQ slot, builds OSC messages
  ↓ UDP to 127.0.0.1:9000
VENU360 Companion Module → receives OSC, formats HiQnet commands
  ↓ TCP to 192.168.0.200:19272
dbx DriveRack VENU360 → applies PEQ notch: Band 1, 2500Hz, -6dB, Q=8
```

### User setup in Companion

1. Add both modules: "DoneWell Audio" and "dbx DriveRack VENU360"
2. VENU360 module: set IP of the hardware, enable OSC receive (e.g. port 9000)
3. DWA module: set Mixer Model to "dbx DriveRack VENU360", Mixer IP to `127.0.0.1`, Port to `9000`
4. DWA prefix field: output channel number (`1` through `6`) — this selects which PEQOut the notch filters target
5. For GEQ mode: set prefix to chain number (`1`=A, `2`=B, `3`=C)

### Key details

- **PEQ bands:** 8 per output (PEQOut1-6). The VENU360 has 6 outputs × 8 PEQ bands = 48 total PEQ slots. DWA manages up to 8 per selected output.
- **GEQ bands:** 31 per chain (GEQ1-3). Band index 0-30 maps to the 31 ISO frequencies (20Hz-20kHz).
- **Frequency handling:** DWA sends frequency as a float in Hz. The VENU360 module's OSC handler auto-formats numbers into the device's string convention (250 → "250Hz", 1000 → "1kHz", 12500 → "12.5kHz").
- **Rate limiting:** The VENU360 module throttles incoming OSC to 20 updates/sec per path, so rapid DWA advisories won't flood the hardware.
- **No duplicate connections:** Only the VENU360 module connects to the hardware. DWA talks to it via localhost OSC.

### Build and test

```bash
cd companion-module
npm run build   # TypeScript compile
```

The profile is pure data — no new runtime dependencies, no new config fields, no new transport code.
