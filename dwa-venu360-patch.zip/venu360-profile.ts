/**
 * VENU360 mixer profile for DWA Companion module.
 *
 * Sends OSC to the VENU360 Companion module's OSC receive port.
 * The VENU360 module handles HiQnet TCP translation, auth, throttling,
 * and state management. No duplicate connections to the hardware.
 *
 * Setup: run both DWA and VENU360 modules in Companion. Point DWA's
 * mixer IP at the Companion host (127.0.0.1 if same machine) and set
 * the port to the VENU360 module's OSC Receive Port.
 *
 * OSC path convention: /venu360/peqout/{instance}/band/{band}/{param}
 * Frequency sent as float Hz (e.g. 250.0, 1000.0, 12500.0).
 * The VENU360 module formats this into the device's string convention.
 *
 * The "prefix" config field selects which output channel (1-6 for PEQ)
 * or input chain (1-3 for GEQ). Default "1".
 */

import type { EqMessage } from './mixerProfiles.js'

// ═══ VENU360 PEQ via OSC ═══

function buildVenu360PeqEq(
  prefix: string,
  band: number,
  freqHz: number,
  gainDb: number,
  q: number,
): EqMessage {
  const inst = prefix || '1'
  return {
    protocol: 'osc',
    oscMessages: [
      { address: `/venu360/peqout/${inst}/band/${band}/freq`, args: [{ type: 'f', value: freqHz }] },
      { address: `/venu360/peqout/${inst}/band/${band}/gain`, args: [{ type: 'f', value: gainDb }] },
      { address: `/venu360/peqout/${inst}/band/${band}/q`, args: [{ type: 'f', value: q }] },
    ],
  }
}

function clearVenu360PeqEq(prefix: string, band: number): EqMessage {
  const inst = prefix || '1'
  return {
    protocol: 'osc',
    oscMessages: [
      { address: `/venu360/peqout/${inst}/band/${band}/gain`, args: [{ type: 'f', value: 0 }] },
    ],
  }
}

// ═══ VENU360 GEQ via OSC ═══

function buildVenu360Geq(prefix: string, bandIndex: number, gainDb: number): EqMessage {
  const inst = prefix || '1'
  return {
    protocol: 'osc',
    oscMessages: [
      { address: `/venu360/geq/${inst}/band/${bandIndex + 1}`, args: [{ type: 'f', value: gainDb }] },
    ],
  }
}

// ═══ Profile definition ═══
// Add this to the MIXER_PROFILES record and MixerModelId union in mixerProfiles.ts

export const VENU360_PROFILE = {
  id: 'venu360' as const,
  label: 'dbx DriveRack VENU360',
  protocol: 'osc' as const,
  defaultPort: 9000,
  peqBands: 8,
  defaultOscPrefix: '1',
  buildEqMessage: (p: { prefix: string; band: number; freqHz: number; gainDb: number; q: number }) =>
    buildVenu360PeqEq(p.prefix, p.band, p.freqHz, p.gainDb, p.q),
  buildClearMessage: (p: { prefix: string; band: number }) =>
    clearVenu360PeqEq(p.prefix, p.band),
  buildGeqMessage: (p: { prefix: string; bandIndex: number; gainDb: number }) =>
    buildVenu360Geq(p.prefix, p.bandIndex, p.gainDb),
}
